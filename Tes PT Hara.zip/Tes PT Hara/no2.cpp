#include <stdio.h>
#include <string.h>
#include <ctype.h>

// Fungsi untuk mengubah semua karakter menjadi huruf kecil
void toLowercase(char *str) {
    int i = 0;
    while (str[i]) {
        str[i] = tolower(str[i]);
        i++;
    }
}

// Fungsi untuk memeriksa apakah sebuah string merupakan palindrome
int isPalindrome(char *str) {
    int i = 0;
    int j = strlen(str) - 1;

    while (i < j) {
        if (str[i] != str[j]) {
            return 0; // Bukan palindrome
        }
        i++;
        j--;
    }
    return 1; // Palindrome
}

int main() {
    char sentence[100];

    while (1) {
        // Input kalimat dari pengguna
        printf("Masukkan sebuah kalimat (ketik 'exit' untuk keluar): ");
        fgets(sentence, sizeof(sentence), stdin);

        // Menghapus karakter newline dari fgets
        sentence[strcspn(sentence, "\n")] = '\0';

        // Keluar dari loop jika pengguna memasukkan 'exit'
        if (strcmp(sentence, "exit") == 0) {
            break;
        }

        // Mengubah semua karakter menjadi huruf kecil
        toLowercase(sentence);

        // Memeriksa apakah kalimat tersebut merupakan palindrome
        if (isPalindrome(sentence)) {
            printf("Kalimat \"%s\" adalah palindrome.\n", sentence);
        } else {
            printf("Kalimat \"%s\" bukan palindrome.\n", sentence);
        }
    }

    return 0;
}

