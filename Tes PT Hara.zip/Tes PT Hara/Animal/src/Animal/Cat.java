/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Animal;

/**
 *
 * @author genic
 */
public class Cat extends Animal {
    public static void main(String[] args) {
        Cat myCat = new Cat();
        myCat.walk();
    }
}

