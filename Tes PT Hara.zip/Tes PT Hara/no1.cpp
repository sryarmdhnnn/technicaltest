#include <iostream>

using namespace std;

void displayOddNumbers(int N) {
    int count = 0;
    int num = 1;

    cout << "Output: ";
    while (count < N) {
        cout << num << " ";
        num += 2;
        count++;
    }
    cout << endl;
}

int main() {
    int N;
    char choice;

    do {
        cout << "Input N: ";
        cin >> N;

        displayOddNumbers(N);

        cout << "Do you want to continue (Y/N)? ";
        cin >> choice;
    } while (choice == 'Y' || choice == 'y');

    return 0;
}

